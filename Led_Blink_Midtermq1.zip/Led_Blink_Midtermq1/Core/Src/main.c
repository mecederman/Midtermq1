#include "main.h"
#include "usb_host.h"

/* Functions */
void init_leds();
void turn_name_on();
void turn_surname_on();
void turn_name_off();
void turn_surname_off();

int main(void)
{
        init_leds();
        int i;
            for(i=0;i<5;i++){
            turn_name_on();
            delay(9000);
            turn_name_off();
            delay(9000);

        }
            for(i=0;i<5;i++){
                turn_suname_on();
                delay(9000);
                turn_surname_off();
                delay(9000);


}

void init_leds()
{
    RCC->AHB1ENR |= (1<<3);
    GPIOD->MODER =(1<<24);
    GPIOD->MODER |=(1<<28);
}
// isim 14 soyisim 12

void turn_name_on(){
    GPIOD->ODR=(1<<14);
}
void turn_surname_on(){
 GPIOD->ODR=(1<<12);
}
void turn_name_off(){
    GPIOD->ODR=~(1<<14);
}
void turn_surname_off(){
 GPIOD->ODR=~(1<<12);
}
void delay(uint32_t sure)
{
    while(sure--);
}
